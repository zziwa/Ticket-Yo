import NormalA from 'components/A';

const A = NormalA.extend`
  padding: 2em 0;
`;

export default A;
